Queen Beryl (Dark Kingdom)
Skin for WinAmp

    by Tata aka Zoi!
    sadly@au.ru
    24.01.01